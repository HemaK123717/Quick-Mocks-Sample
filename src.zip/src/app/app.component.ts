import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  appName: string = '';
  seal: string = '';
  path: string = '';
  requestMethod: string = '';
  
  displayMessage() {
    let lowerCaseRequestMtd = this.requestMethod.toLowerCase();
    Swal("Data Submitted! Use Mock url", 'https://quick-mocks-dev.jpmchase.xyz/'+ lowerCaseRequestMtd +"-mock/"+ this.seal+"-"+this.appName + "/"+ this.path, "success");
  }
}
